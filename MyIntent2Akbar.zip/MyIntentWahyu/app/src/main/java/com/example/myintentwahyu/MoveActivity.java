package com.example.myintentwahyu;

import android.app.Activity;

public class MoveActivity extends Activity {
}
